// app/profile/layout.js
export const dynamic = 'force-dynamic';

export default function ProfileLayout({ children }) {
  return children;
}
